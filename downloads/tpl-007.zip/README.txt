TERRA CRAFT — SLIPKIT Receipt Template
=======================================

Style: Organic / Botanical Minimal
Color: Forest green + Terracotta brown + Warm cream
Best for: Café, Bakery, Eco brand, Artisan, Wellness

ไฟล์ในแพ็กเกจ:

1. tpl-007-terra-craft.html
   - เปิดด้วย browser (double-click)
   - แก้ชื่อ/รายการ/ราคา ใน Notepad ได้
   - กด Ctrl+P → Save as PDF

2. tpl-007-terra-craft.svg
   - เปิด/แก้ใน Figma, Illustrator, Inkscape
   - text เป็น vector แก้ได้

License: ใช้งานเชิงพาณิชย์ฟรี ไม่ต้องให้เครดิต
ที่มา: bearalot.com — SLIPKIT
