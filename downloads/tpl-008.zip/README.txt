BENTO STACK - SLIPKIT Receipt Template
======================================

Style: Bento / Modular Grid
Color: Slate navy + Mustard yellow + Clean white
Best for: Tech, SaaS, Product launch, Fintech subscription

Files in this package:

1. tpl-008-bento-stack.html
   - Open in browser (double-click)
   - Edit in Notepad to customize
   - Ctrl+P to save as PDF

2. tpl-008-bento-stack.svg
   - Open/edit in Figma, Illustrator, Inkscape
   - Text is editable vector
   - Scales without quality loss

License: Free for commercial use, no attribution required
Source: bearalot.com - SLIPKIT
